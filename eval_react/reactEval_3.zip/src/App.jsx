import { useState } from "react";
import { CustomButton } from "./component/CustomButton";
import { CustomInput } from "./component/CustomInput";
import { CustomSelect } from "./component/CustomSelect";
import "./App.css";

function App() {
  const [options, setOptions] = useState(["Travail", "Perso", "Maison"]);
  const [selectedCategorie, setSelectedCategorie] = useState("");
  const [filterCategorie, setFilterCategorie] = useState("Toutes");
  const [newCategory, setNewCategory] = useState("");
  const [newTask, setNewTask] = useState("");
  const [tasks, setTasks] = useState([]);

  const handleAddCategory = () => {
    const trimmed = newCategory.trim();
    const lowerOptions = options.map((opt) => opt.toLowerCase());
    if (trimmed && !lowerOptions.includes(trimmed.toLowerCase())) {
      setOptions([...options, trimmed]);
      setNewCategory("");
    }
  };

  const handleAddTask = () => {
    const trimmed = newTask.trim();
    if (trimmed && selectedCategorie) {
      setTasks([
        ...tasks,
        {
          id: Date.now(),
          text: trimmed,
          category: selectedCategorie,
          isCompleted: false,
        },
      ]);
      setNewTask("");
    }
  };

  const toggleComplete = (id) => {
    setTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, isCompleted: !task.isCompleted } : task
      )
    );
  };

  const handleDeleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const filteredTasks = tasks.filter(
    (task) => filterCategorie === "Toutes" || task.category === filterCategorie
  );

  return (
    <div className="app-container">
      <section className="vertical-gap">
        <h1>Ma To-Do List par Catégories</h1>

        <div className="row">
          <CustomInput
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            placeholder="Nouvelle catégorie"
          />
          <CustomButton onClick={handleAddCategory}>
            Ajouter une catégorie
          </CustomButton>
        </div>

        <div className="row w-full">
          <CustomSelect
            value={filterCategorie}
            onChange={(e) => setFilterCategorie(e.target.value)}
            options={["Toutes", ...options]}
            placeholder="Filtrer par catégorie"
            className="w-full"
          />
        </div>

        <div className="row">
          <CustomInput
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="Nouvelle tâche"
          />
          <CustomSelect
            value={selectedCategorie}
            onChange={(e) => setSelectedCategorie(e.target.value)}
            options={options}
            placeholder="Sélectionnez une catégorie"
          />
          <CustomButton onClick={handleAddTask}>Ajouter une tâche</CustomButton>
        </div>
      </section>

      <section className="task-list">
        {filteredTasks.length === 0 ? (
          <p>Aucune tâche à afficher.</p>
        ) : (
          <ul>
            {filteredTasks.map((task) => (
              <li key={task.id} className="task-item">
                <input
                  type="checkbox"
                  checked={task.isCompleted}
                  onChange={() => toggleComplete(task.id)}
                />
                <span className={task.isCompleted ? "completed" : ""}>
                  [{task.category}] {task.text}
                </span>
                <button onClick={() => handleDeleteTask(task.id)}>
                  Supprimer
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

export default App;
