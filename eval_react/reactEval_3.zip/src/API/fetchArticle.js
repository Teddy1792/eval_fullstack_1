export async function fetchArticle() {
  const url = "https://jsonplaceholder.typicode.com/posts/";
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Response status: ${response.status}`);
    }
    const json = await response.json();
    return json;
  } catch (error) {
    console.log(error);
    return null;
  }
}
