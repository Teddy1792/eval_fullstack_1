export function CustomSelect({
  options,
  value,
  onChange,
  className = "",
  placeholder = "Choisir une catégorie",
}) {
  return (
    <select
      value={value}
      onChange={onChange}
      className={`custom-select ${className}`}
    >
      <option value="">{placeholder}</option>
      {options.map((opt, idx) => (
        <option key={idx} value={opt}>
          {opt}
        </option>
      ))}
    </select>
  );
}
